import { describe, expect, it } from 'vitest'
import definitions from '../data/gift-codes.json'
import { cardById } from '../data/cards'
import { boosters } from '../data/boosters'
import { shopBoosters } from '../game/boosterAvailability'
import { GIFT_CODE_HASH_PATTERN } from './format'
import type { GiftCodeDefinition } from './types'

describe('catalogue public des cadeaux', () => {
  it('ne publie que des empreintes uniques et des récompenses valides', () => {
    const gifts = definitions as GiftCodeDefinition[]
    expect(new Set(gifts.map(gift => gift.codeHash)).size).toBe(gifts.length)
    const available = new Set(shopBoosters(boosters).map(booster => booster.id))
    for (const gift of gifts) {
      expect(Object.keys(gift).sort()).toEqual(['codeHash', 'expiresAt', 'issuedAt', 'reward'])
      expect(gift.codeHash).toMatch(GIFT_CODE_HASH_PATTERN)
      expect(Number.isSafeInteger(gift.issuedAt) && gift.issuedAt >= 0).toBe(true)
      expect(Number.isSafeInteger(gift.expiresAt) && gift.expiresAt > gift.issuedAt).toBe(true)
      if (gift.reward.type === 'booster') {
        expect(available.has(gift.reward.boosterId)).toBe(true)
        expect(Number.isSafeInteger(gift.reward.quantity) && gift.reward.quantity > 0).toBe(true)
        if (gift.reward.fragments !== undefined) expect(Number.isSafeInteger(gift.reward.fragments) && gift.reward.fragments > 0).toBe(true)
      } else if (gift.reward.type === 'boosters') {
        expect(gift.reward.boosters.length).toBeGreaterThan(0)
        expect(new Set(gift.reward.boosters.map(item => item.boosterId)).size).toBe(gift.reward.boosters.length)
        for (const item of gift.reward.boosters) {
          expect(available.has(item.boosterId)).toBe(true)
          expect(Number.isSafeInteger(item.quantity) && item.quantity > 0).toBe(true)
        }
      } else if (gift.reward.type === 'promo-card') {
        expect(cardById.get(gift.reward.cardId)?.promoNumber).toBeDefined()
      } else if (gift.reward.type === 'weekly-bonus') {
        expect(['reroll', 'fragments']).toContain(gift.reward.bonus)
        expect(Number.isSafeInteger(gift.reward.quantity) && gift.reward.quantity > 0).toBe(true)
      } else {
        expect(gift.reward.type).toBe('fragments')
        expect(Number.isSafeInteger(gift.reward.amount) && gift.reward.amount > 0).toBe(true)
      }
    }
  })
})
