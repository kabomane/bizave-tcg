export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary'
export type Finish = 'normal' | 'glossy' | 'alternative'
export type ArtVariant = 'standard' | 'fullArt'
export type CardDefinition = {
  id: string; title: string; description: string; rarity: Rarity; collectionId: string
  artwork: { standard: string; fullArt: string }; artworkPosition?: Partial<Record<ArtVariant, string>>; weight?: number
  promoNumber?: string
}
type CardPoolSource =
  | { type: 'collection'; collectionId: string; excludeCardIds?: string[]; multiplier?: number }
  | { type: 'cards'; cardIds: string[]; multiplier?: number }
  | { type: 'rarities'; rarities: Rarity[]; multiplier?: number }
type BoosterShopOffer = { price: number; listed?: boolean }
export type BoosterDefinition = {
  id: string; title: string; subtitle: string; description: string
  artwork: { emoji?: string; design?: 'sachet' | 'bloc'; colors: { primary: string; secondary: string; shine: string; glow: string } }
  access: { type: 'free'; shop?: BoosterShopOffer } | ({ type: 'shop' } & BoosterShopOffer)
  cardsPerPack: number; sources: CardPoolSource[]; enabled: boolean; order: number
  showInFilters?: boolean
  rates?: {
    rarity?: 'default' | Record<Rarity, number>
    finish?: 'default' | Record<Finish, number>
    illustration?: 'default' | Record<ArtVariant, number>
  }
}
export type Card = { dropId: string; cardId: string; finish: Finish; artVariant: ArtVariant }
export type FavoriteRow = Pick<Card, 'cardId' | 'finish' | 'artVariant'> & { key: string }
export type CardDropRow = Card & { status: 'owned' | 'outgoing' | 'recycled'; acquiredAt: number; updatedAt: number; circulation?: 'local' | 'exchanged' }
export type RecycledCardRow = { dropId: string }
export type CardDiscoveryRow = Omit<Card, 'dropId'> & { key: string; firstDiscoveredAt: number }
export type WeeklyBonusKind = 'reroll' | 'fragments'
export type PlayerStateRow = {
  id: 'local'; fragments: number; freePackStock: number; nextFreePackAt: number | null
  maxObservedClockAt: number; schemaVersion: number
  weeklyBonusCredits?: Partial<Record<WeeklyBonusKind, number>>
}
export type OpenRecord = {
  id: string; boosterId: string; boosterTitle?: string; openedAt: number; payment: 'free' | 'fragments' | 'shop'
  boosterColors?: BoosterDefinition['artwork']['colors']
  fragmentsSpent: number; results: Card[]; revealComplete: boolean; revealedCount: number
}
export type BoosterStockRow = { boosterId: string; quantity: number; updatedAt: number }
export type BoosterPurchaseRow = { id: string; boosterId: string; boosterTitle: string; unitPrice: number; fragmentsSpent: number; createdAt: number }
export type RecyclingRecord = { id: string; createdAt: number; dropIds: string[]; fragmentsGained: number }
export type LocalIdentityRow = {
  id: 'local'; playerUuid: string; signingPrivateKey: CryptoKey; signingPublicJwk: JsonWebKey
  createdAt: number
}
export type FriendContactRow = {
  playerUuid: string; signingPublicJwk: JsonWebKey
  fingerprint: string; label?: string; addedAt: number
}
export type TransferPayload = Card & { version: 2; transferId: string; senderId: string; recipientId: string; issuedAt: number }
export type FragmentTransferPayload = { version: 1; transferId: string; senderId: string; recipientId: string; issuedAt: number; amount: number }
type OutgoingBase = { transferId: string; recipientId: string; recipientLabel?: string; code: string; createdAt: number; status: 'generated' }
export type OutgoingTransferRow =
  | OutgoingBase & { kind: 'card'; dropId: string }
  | OutgoingBase & { kind: 'fragments'; amount: number }
export type UsedTransferRow = { transferId: string; receivedAt: number }
